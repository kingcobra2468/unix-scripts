file=$1
file="$PWD/$file"
content=""
cat $file
content=$(cat $file | tr '[ "$" "@" "#" "!" "^" "%" "*" "&" "+" "(" ]' '[ "f" "g" "h" "i" "j" "k" "l" "m" "n" "o" ]' )
echo $content
content=$(echo $content | tr '[W-ZA-Vw-za-v]' '[A-Za-z]') 
echo $content

echo $content > $file
