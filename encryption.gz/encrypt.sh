file=$1
echo $HOME
echo $PWD
file="$PWD/$file"
content=""
echo $file
content=$(cat $file | tr '[A-Za-z]' '[W-ZA-Vw-za-v]') 
cat $file 
echo $content
content=$(echo $content | tr '["f" "g" "h" "i" "j" "k" "l" "m" "n" "o"]' '["$" "@" "#" "!" "^" "%" "*" "&" "+" "("]' )
echo $content
echo $content > $file
